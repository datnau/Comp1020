FILE_NAME = "iris.csv"
COMMA_DELIMITER = ","
SEPAL_LENGTH_INDEX = 0
SEPAL_WIDTH_INDEX = 1
PETAL_LENGTH_INDEX = 2
PETAL_WIDTH_INDEX = 3
VARIETY_INDEX = 4
EXPECTED_PARTS = 5

def main() -> None:
    try:

        size = count_lines(FILE_NAME)

        # Initialize lists with a fixed size to match the Java approach
        sepal_length = [0.0] * size
        sepal_width = [0.0] * size
        petal_length = [0.0] * size
        petal_width = [0.0] * size
        variety = [""] * size

        print("Reading {} lines of data...".format(size))
        print("-" * 50)

        # 1. Using "Scanner" equivalent (split on whitespace after replace)
        print("Parsing with Python open() + value replacement...")
        parse_data_with_replacement(FILE_NAME, sepal_length, sepal_width, petal_length, petal_width, variety)
        print_first_and_last(size, sepal_length, variety)
        print("-" * 50)

        # 2. Using split(',')
        print("Parsing with Python open() + split...")
        parse_data_with_split(FILE_NAME, sepal_length, sepal_width, petal_length, petal_width, variety)
        print_first_and_last(size, sepal_length, variety)
        print("-" * 50)

        # 3. Using Manual Parsing
        print("Parsing with Python open() + Manual Substring...")
        parse_data_manual(FILE_NAME, sepal_length, sepal_width, petal_length, petal_width, variety)
        print_first_and_last(size, sepal_length, variety)
        print("-" * 50)

        print("End of processing.")

    except IOError as e:
        print("Error processing file: {}".format(e))

def print_first_and_last(size: int, sepal_length: list[float], variety: list[str]) -> None:
    """
    Prints the first and last entry of the parsed data to verify correctness.
    """
    if size > 0:
        print("First entry: {}, {}".format(variety[0], sepal_length[0]))
        print("Last entry: {}, {}".format(variety[size - 1], sepal_length[size - 1]))

def count_lines(file_name: str) -> int:
    """
    Counts the number of lines in the file, excluding the header.
    """
    counter = 0
    with open(file_name, 'r') as f:
        # Skip header
        f.readline()

        for line in f:
            if line.strip():
                counter += 1
    return counter

def add_to_arrays(index: int, parts: list[str], sepal_length: list[float], sepal_width: list[float], petal_length: list[float], petal_width: list[float], variety: list[str]) -> None:
    """
    Helper method to populate the data lists from a list of parts.
    """
    # Convert first four to float
    sepal_length[index] = float(parts[SEPAL_LENGTH_INDEX])
    sepal_width[index] = float(parts[SEPAL_WIDTH_INDEX])
    petal_length[index] = float(parts[PETAL_LENGTH_INDEX])
    petal_width[index] = float(parts[PETAL_WIDTH_INDEX])

    # Handle the variety string
    val = parts[VARIETY_INDEX].strip()
    variety[index] = val

def parse_data_with_replacement(file_name: str, sepal_length: list[float], sepal_width: list[float], petal_length: list[float], petal_width: list[float], variety: list[str]) -> None:
    """
    Parses the data file using a strategy similar to the Java Scanner approach
    (replacing delimiters with spaces and splitting on whitespace).
    """
    with open(file_name, 'r') as f:
        # Skip header
        f.readline()

        counter = 0
        for line in f:
            if line.strip():
                # Replace commas with spaces, then split on whitespace
                line_replaced = line.replace(COMMA_DELIMITER, " ")
                parts = line_replaced.split()

                # Take only the first EXPECTED_PARTS in case of trailing issues
                if len(parts) >= EXPECTED_PARTS:
                    add_to_arrays(counter, parts, sepal_length, sepal_width, petal_length, petal_width, variety)
                    counter += 1

def parse_data_with_split(file_name: str, sepal_length: list[float], sepal_width: list[float], petal_length: list[float], petal_width: list[float], variety: list[str]) -> None:
    """
    Parses the data file using string split().
    """
    with open(file_name, 'r') as f:
        # Skip header
        f.readline()

        counter = 0
        for line in f:
            if line.strip():
                parts = line.strip().split(COMMA_DELIMITER)

                if len(parts) >= EXPECTED_PARTS:
                    add_to_arrays(counter, parts, sepal_length, sepal_width, petal_length, petal_width, variety)
                    counter += 1

def parse_data_manual(file_name: str, sepal_length: list[float], sepal_width: list[float], petal_length: list[float], petal_width: list[float], variety: list[str]) -> None:
    """
    Parses the data file using manual substring logic.
    """
    with open(file_name, 'r') as f:
        # Skip header
        f.readline()

        counter = 0
        for line in f:
            if line.strip():
                parts = manual_split(line.strip())

                add_to_arrays(counter, parts, sepal_length, sepal_width, petal_length, petal_width, variety)
                counter += 1

def manual_split(line: str) -> list[str]:
    """
    Manually splits a string by comma delimiter.
    """
    parts = [""] * EXPECTED_PARTS
    part_index = 0
    start = 0

    for i in range(len(line)):
        if line[i] == ',':
            if part_index < EXPECTED_PARTS:
                parts[part_index] = line[start:i]
                part_index += 1
            start = i + 1

    # Get the last part
    if start < len(line) and part_index < EXPECTED_PARTS:
        parts[part_index] = line[start:]

    return parts

if __name__ == "__main__":
    main()
