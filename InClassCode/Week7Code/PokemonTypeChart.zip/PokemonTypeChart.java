import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class PokemonTypeChart {

    private static final double NEUTRAL = 1.0;
    private static final double IMMUNE = 0.0;
    private static final double TOL = 1E-6;

    private ArrayList<String> typeNames;
    private double[][] typeChart;

    public PokemonTypeChart(String csvFile) {
        parseCsv(csvFile);
    }

    private void parseCsv(String csvFile) {
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line = br.readLine();

            if (line == null) throw new IOException("CSV file is empty");

            // First item is empty, rest are types
            String[] headers = line.split(",");
            this.typeNames = new ArrayList<>();
            // Start from 1 skipping the first empty column
            for (int i = 1; i < headers.length; i++) {
                this.typeNames.add(headers[i].trim());
            }

            int n = this.typeNames.size();
            this.typeChart = new double[n][n];

            int rowIdx = 0;
            while ((line = br.readLine()) != null && rowIdx < n) {
                String[] parts = line.split(",");
                // parts[0] is the row type name, usually matches typeNames[rowIdx]
                // Data starts from index 1.
                // Note: The CSV might have empty first cell so
                //     parts[0] might be empty if line starts with comma?
                // Actually the csv example: Fire,1.0,0.5... -> parts[0]="Fire"
                for (int colIdx = 0; colIdx < n; colIdx++) {
                    if (colIdx + 1 < parts.length) {
                        this.typeChart[rowIdx][colIdx] = Double.parseDouble(parts[colIdx + 1]);
                    }
                }
                rowIdx += 1;
            }

        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private int getIndex(String type) {
        return this.typeNames.indexOf(type);
    }

    private String getShortName(String typeName) {
        String shortName = typeName;

        if (typeName.length() > 3) {
            shortName = typeName.substring(0, 3);
        }

        return shortName;
    }

    private void printHeader() {
        System.out.print("   |");
        for (String name : typeNames) {
            String shortName = name.length() > 3 ? name.substring(0, 3) : name;
            System.out.printf("%s|", shortName.toUpperCase());
        }
        System.out.println();
    }

    private void printRow(String attacker, double[] effectiveness) {
        String shortName = getShortName(attacker);

        System.out.printf("%s|", shortName.toUpperCase());

        for (double val : effectiveness) {
            if (Math.abs(val - NEUTRAL) < TOL) {
                // blank for neutral
                System.out.print("   |");
            } else if (Math.abs(val - IMMUNE) < TOL) {
                // 0 for immune
                System.out.print(" 0 |");
            } else if (val > NEUTRAL) {
                // super effective, e.g. 2 or 4
                System.out.printf("%2.0f |", val);
            } else if (val > IMMUNE && val < NEUTRAL) {
                // not very effective, e.g. 1/2 or 1/4
                System.out.printf("1/%.0f|", 1.0 / val);
            } else {
                System.out.print("Err|");
            }
        }
        System.out.println();
    }

    public void printTypeChart(double[][] chart) {
        printHeader();
        for (int i = 0; i < typeNames.size(); i++) {
            printRow(typeNames.get(i), chart[i]);
        }
    }

    public void printDualTypeChart(String secondaryType) {
        int secIdx = getIndex(secondaryType);
        if (secIdx == -1) {
            System.out.println("Type not found: " + secondaryType);
            return;
        }

        int n = typeNames.size();

        // Construct the dual type chart
        double[][] dualChart = new double[n][n];

        // target_col = type_chart[:, NAME_TO_IDX[dual_type]]
        // This is the column for the secondary type (how each attacker hits the secondary type)
        double[] targetCol = new double[n];
        for (int r = 0; r < n; r++) {
            targetCol[r] = typeChart[r][secIdx];
        }

        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                 double primaryEffectiveness = typeChart[r][c];

                 if (c != secIdx) {
                     // Multiply by secondary effectiveness
                     dualChart[r][c] = primaryEffectiveness * targetCol[r];
                 } else {
                     // Keep as is for the column corresponding to the secondary type itself
                     // (Though the header will be blank effectively)
                     dualChart[r][c] = primaryEffectiveness;
                 }
            }
        }

        // Print "Extra Header" with secondary type names
        System.out.print("   |");
        String secShort = getShortName(secondaryType).toUpperCase();

        for (int c = 0; c < n; c++) {
            if (c != secIdx) {
                System.out.printf("%s|", secShort);
            } else {
                System.out.print("   |");
            }
        }
        System.out.println();

        printTypeChart(dualChart);
    }

    public static void main(String[] args) {
        String csvPath = "pokemon_type_chart.csv";

        PokemonTypeChart ptc = new PokemonTypeChart(csvPath);

        if (ptc.typeNames == null || ptc.typeNames.isEmpty()) {
            throw new RuntimeException("Failed to load chart from: " + csvPath);
        }

        System.out.println("--- Single Type Chart ---");
        ptc.printTypeChart(ptc.typeChart);
        System.out.println();

        String secondaryType = "Fire";
        System.out.println(String.format("--- Dual Type Chart (Secondary: %s) ---", secondaryType));
        ptc.printDualTypeChart(secondaryType);
    }
}
